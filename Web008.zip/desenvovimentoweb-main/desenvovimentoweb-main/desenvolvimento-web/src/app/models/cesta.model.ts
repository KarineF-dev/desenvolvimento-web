import { ItemCesta } from './item-cesta.model';

export interface Cesta {
  id: number;
  itens: ItemCesta[];
  valorTotal: number;
}