import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms'; 

@Component({
  selector: 'app-barra-busca',
  standalone: true,
  imports: [FormsModule], 
  templateUrl: './barra-busca.html', 
  styleUrls: ['./barra-busca.css']   
})
export class BarraBuscaComponent {
  
  termoBusca: string = '';

  
  salvarBusca() {
    localStorage.setItem('buscaSalva', this.termoBusca);
    console.log('Salvo no storage:', this.termoBusca); 
  }
}