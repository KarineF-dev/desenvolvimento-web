import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms'; // 1. Importe aqui

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule], // 2. Adicione aqui!
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class LoginComponent {
  // 3. Objeto para guardar as credenciais
  credenciais = {
    email: '',
    senha: ''
  };

  fazerLogin() {
    console.log('Dados do login:', this.credenciais);
  }
}